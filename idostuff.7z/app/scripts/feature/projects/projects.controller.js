'use strict';

angular
    .module('idostuff')
    .controller('ProjectsCtrl', ProjectsCtrl);

function ProjectsCtrl() {
  
}