'use strict';

angular
    .module('idostuff')
    .controller('DescCtrl', DescCtrl);

function DescCtrl() {
  
}
