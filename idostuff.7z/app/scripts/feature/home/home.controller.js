'use strict';

angular
    .module('idostuff')
    .controller('HomeCtrl', HomeCtrl);

function HomeCtrl() {
  
}