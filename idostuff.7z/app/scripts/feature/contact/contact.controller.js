'use strict';

angular
    .module('idostuff')
    .controller('ContactCtrl', ContactCtrl);

function ContactCtrl() {
  
}